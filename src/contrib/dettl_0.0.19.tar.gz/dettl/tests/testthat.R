library(testthat)
library(dettl)

test_check("dettl")
