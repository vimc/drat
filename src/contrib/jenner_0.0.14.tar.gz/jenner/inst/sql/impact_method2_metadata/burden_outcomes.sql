SELECT id, code
FROM burden_outcome
