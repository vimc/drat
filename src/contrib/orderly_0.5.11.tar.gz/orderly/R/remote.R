##' Download dependent reports (WARNING: this is still in transition
##' and the docs may not be entirely accurate)
##'
##' If \code{remote} is a \code{montagu_server} object then this
##' requires the montagu package and for montagu's credentials to be
##' correctly set up.  The \code{pull_archive} function pulls report
##' directly (without it being a dependent report).
##'
##' To use this functionality you will need to have \code{montagu}
##' installed, and be part of the VIMC team.  To set it up run
##'
##' \preformatted{
##' options(montagu.username = "your.email@imperial.ac.uk")
##' }
##'
##' You can add that line to your \code{~/.Rprofile} file perhaps -
##' see \code{path.expand("~/.Rprofile")} for where this file lives on
##' your computer.  After setting your username up you can run
##' \code{pull_dependencies("reportname")} to pull the
##' \emph{dependencies} of \code{"reportname"} down so that
##' \code{"reportname"} can be run, or you can run
##' \code{pull_archive("reportname")} to pull a copy of
##' \code{"reportname"} that has been run on the production server.
##'
##' @title Download dependent reports
##' @param name Name of the report to download dependencies for
##'
##' @param remote Description of the location.  This must be an
##'   \code{orderly_remote} object.
##'
##' @inheritParams orderly_list
##' @export
pull_dependencies <- function(name, config = NULL, locate = TRUE,
                              remote = NULL) {
  config <- orderly_config_get(config, locate)

  path <- file.path(path_src(config$path), name)
  depends <- recipe_read(path, config, FALSE)$depends

  for (i in seq_len(nrow(depends))) {
    if (!isTRUE(depends$draft[[i]])) {
      pull_archive(depends$name[[i]], depends$id[[i]], config, remote = remote)
    }
  }
}


##' @export
##' @rdname pull_dependencies
##'
##' @param id The identifier (for \code{pull_archive}.  The default is
##'   to use the latest report.
pull_archive <- function(name, id = "latest", config = NULL, locate = TRUE,
                         remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  v <- remote_report_versions(name, config, FALSE, remote)
  if (length(v) == 0L) {
    stop("Unknown report")
  }

  if (id == "latest") {
    id <- latest_id(v)
  }

  if (!(id %in% v)) {
    ## Confirm that the report does actually exist, working around
    ## VIMC-1281:
    stop(sprintf(
      "Version '%s' not found at '%s': valid versions are:\n%s",
      id, remote_name(remote), paste(sprintf("  - %s", v), collapse = "\n")),
      call. = FALSE)
  }

  dest <- file.path(path_archive(config$path), name, id)

  if (file.exists(file.path(dest, "orderly_run.yml"))) {
    orderly_log("pull", sprintf("%s:%s already exists, skipping", name, id))
  } else {
    orderly_log("pull", sprintf("%s:%s", name, id))

    check_remote_type(remote)
    if (inherits(remote, "montagu_server")) {
      remote_report_pull_archive_api(name, id, config, remote)
    } else if (inherits(remote, "orderly_remote_path")) {
      remote_report_pull_archive_path(name, id, config, remote)
    }
  }
}


##' Push an archive report to a remote location.
##'
##' This is experimental and only supported using paths for
##' \code{remote}.  It will be useful for doing something like sharing
##' preliminary artefacts peer-to-peer before running centrally.  It
##' is not supported (yet) for pushing onto a montagu server, but that
##' would be nice to have (probably locked down the same way that the
##' \code{ref} argument is).
##'
##' @title Push an archive report to a remote location
##' @inheritParams pull_dependencies
##' @export
push_archive <- function(name, id = "latest", config = NULL, locate = TRUE,
                         remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  if (id == "latest") {
    id <- orderly_latest(name, config, FALSE)
  }

  v <- remote_report_versions(name, config, FALSE, remote)
  if (id %in% v) {
    orderly_log("push", sprintf("%s:%s already exists, skipping", name, id))
  } else {
    orderly_log("push", sprintf("%s:%s", name, id))

    check_remote_type(remote)
    if (inherits(remote, "montagu_server")) {
      stop("'montagu_server' remotes do not support push (yet)")
    } else if (inherits(remote, "orderly_remote_path")) {
      push_archive_path(name, id, config, remote)
    }
  }
}


##' Run a report on a remote server (for now this means montagu).  Be
##' careful doing this because once a report is run to completion on
##' production it cannot be deleted.  So get things working locally,
##' test on science and then run on production.
##'
##' @title Run a report on montagu
##'
##' @param name Name of the report
##'
##' @param parameters Parameters for the reprt
##'
##' @param timeout Time to wait for the report to be returned (in seconds)
##'
##' @param poll Period to poll the server for results (in seconds)
##'
##' @param open Logical, indicating if the report should be opened in
##'   a browser on completion
##'
##' @param stop_on_error Logical, indicating if we should throw an
##'   error if the report fails.  If you set this to \code{FALSE} it
##'   will be much easier to debug, but more annoying in scripts.
##'
##' @param progress Logical, indicating if a progress spinner should
##'   be included.
##'
##' @param ref Optional reference, indicating which branch should be
##'   used.  This cannot be used on production.
##'
##' @inheritParams pull_dependencies
##'
##' @export
orderly_run_remote <- function(name, parameters = NULL, ref = NULL,
                               timeout = 3600, poll = 1,
                               open = TRUE, stop_on_error = TRUE,
                               progress = TRUE,
                               config = NULL, locate = TRUE, remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  check_remote_type(remote)
  if (inherits(remote, "montagu_server")) {
    orderly_run_remote_api(name = name, parameters = parameters, ref = ref,
                           timeout = timeout, poll = poll, open = open,
                           stop_on_error = stop_on_error,
                           progress = progress,
                           config = config, remote = remote)
  } else if (inherits(remote, "orderly_remote_path")) {
    ## This is actually really easy
    stop("'orderly_remote_path' remotes do not run (yet)")
  }
}

##' Publish a report on a remote server
##'
##' @title Publish orderly report on remote server
##'
##' @param name Name of the report (unlike
##'   \code{\link{orderly_publish}} this must be provided sorry)
##'
##' @param id The report id
##'
##' @param value As \code{\link{orderly_publish}}, \code{TRUE} or
##'   \code{FALSE} to publish or unpublish a report (respectively)
##'
##' @inheritParams orderly_run_remote
##' @export
orderly_publish_remote <- function(name, id, value = TRUE,
                                   config = NULL, locate = TRUE,
                                   remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  assert_scalar_character(name)
  assert_scalar_character(id)
  assert_scalar_logical(value)

  check_remote_type(remote)
  if (inherits(remote, "montagu_server")) {
    orderly_publish_remote_api(name = name, id = id, config = config,
                               value = value, remote = remote)
  } else if (inherits(remote, "orderly_remote_path")) {
    ## This one can actually be done over disk too
    stop("'orderly_remote_path' remotes do not publish (yet)")
  }
}


##' Set and get default remote locations
##'
##' @title Set default remote location
##' @param value A string describing a remote, or \code{NULL} to clear
##' @inheritParams orderly_list
##' @export
##' @rdname default_remote
set_default_remote <- function(value, config = NULL, locate = TRUE) {
  config <- orderly_config_get(config, locate)

  if (is.null(value)) {
    remote <- NULL
  } else {
    assert_scalar_character(value)
    remote <- get_remote(value, config)
  }

  cache$default_remote[[config$path]] <- remote
  invisible(remote)
}


##' @rdname default_remote
get_default_remote <- function(config = NULL, locate = TRUE) {
  config <- orderly_config_get(config, locate)
  if (!is.null(cache$default_remote[[config$path]])) {
    return(cache$default_remote[[config$path]])
  }
  if (length(config$api_server) > 0L) {
    return(check_remote_api_server(config, config$api_server[[1L]]))
  }
  default_remote_path <- Sys.getenv("ORDERLY_DEFAULT_REMOTE_PATH",
                                    NA_character_)
  if (!is.na(default_remote_path)) {
    return(orderly_remote_path(default_remote_path))
  }
  stop("default remote has not been set yet: use 'orderly::set_default_remote'")
}


get_remote <- function(remote, config) {
  if (is.null(remote)) {
    get_default_remote(config)
  } else if (inherits(remote, c("montagu_server", "orderly_remote_path"))) {
    remote
  } else if (is.character(remote)) {
    assert_scalar(remote)
    if (remote %in% names(config$api_server)) {
      check_remote_api_server(config, config$api_server[[remote]])
    } else if (file.exists(remote)) {
      orderly_remote_path(remote)
    } else {
      stop(sprintf("Unknown remote '%s'", remote),
           call. = FALSE)
    }
  } else {
    stop("Unknown remote type ",
         paste(squote(class(remote)), collapse = " / "),
         call. = FALSE)
  }
}


remote_report_names <- function(config = NULL, locate = TRUE, remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  check_remote_type(remote)
  if (inherits(remote, "montagu_server")) {
    remote_report_names_api(remote)
  } else if (inherits(remote, "orderly_remote_path")) {
    remote_report_names_path(remote)
  }
}


remote_report_versions <- function(name, config = NULL, locate = TRUE,
                                   remote = NULL) {
  config <- orderly_config_get(config, locate)
  remote <- get_remote(remote, config)

  check_remote_type(remote)
  if (inherits(remote, "montagu_server")) {
    remote_report_versions_api(name, remote)
  } else if (inherits(remote, "orderly_remote_path")) {
    remote_report_versions_path(name, remote)
  }
}


check_remote_type <- function(remote) {
  if (inherits(remote, "montagu_server") ||
      inherits(remote, "orderly_remote_path")) {
    return(NULL)
  }
  stop("Unknown remote type ",
       paste(squote(class(remote)), collapse = " / "))
}


remote_name <- function(remote) {
  check_remote_type(remote)
  if (inherits(remote, "montagu_server")) {
    remote$name
  } else if (inherits(remote, "orderly_remote_path")) {
    as.character(remote)
  }
}
