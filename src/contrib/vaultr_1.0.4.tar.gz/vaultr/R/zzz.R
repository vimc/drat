vault_env <- new.env(parent = new.env())
vault_env$cache <- token_cache$new()
