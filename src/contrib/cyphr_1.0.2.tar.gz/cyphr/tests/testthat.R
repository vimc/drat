library(testthat)
library(cyphr)

test_check("cyphr")
