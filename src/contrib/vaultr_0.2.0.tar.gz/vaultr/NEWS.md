## 0.2.0

* Complete rewrite based on use over the last year:
  - supporting many more vault methods
  - a better base for ongoing method support
  - rationalised authentication and caching
  - easier to use server for tests

## 0.1.0

* Initial internal release
