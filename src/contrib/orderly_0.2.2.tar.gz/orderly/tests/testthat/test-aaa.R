start_vault()
