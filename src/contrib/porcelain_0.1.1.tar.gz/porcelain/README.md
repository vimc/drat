## porcelain

<!-- badges: start -->
[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![R build status](https://github.com/reside-ic/pkgapi/workflows/R-CMD-check/badge.svg)](https://github.com/reside-ic/pkgapi/actions)
[![codecov.io](https://codecov.io/github/reside-ic/porcelain/coverage.svg?branch=master)](https://codecov.io/github/reside-ic/porcelain?branch=master)

<!-- badges: end -->

## License

MIT © Imperial College of Science, Technology and Medicine
