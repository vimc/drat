### jenner 0.0.4 (2017-11-16)
 * correct impact rate and impact rate type in output files
 * eliminate warning message caused by updating multiple touchstones in one report
 * remove unused codes
 * export mu_scale

### jenner 0.0.4 (2017-11-09)
 * fix suffix in summary_output
 * fix migrate coverage.sql to allow 'bestminus' type of activity (SDF6/7)

### add past versions below
