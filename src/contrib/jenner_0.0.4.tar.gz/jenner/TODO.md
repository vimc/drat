# genreal steps
[1] work on jenner in a <branch_id>
[2] devtools::load_all("../jenner") # with the path modified to match your computer
[3] test if changes in the first step work
[4] step 1-3 interactively until good

# problems solved
-- output of XXX_averted_rate corrected
-- one correction for update one touchstone by itself
-- increase to version 0.0.4
