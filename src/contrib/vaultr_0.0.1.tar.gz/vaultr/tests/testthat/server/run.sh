#!/bin/sh
vault server -config=server/vault-tls.hcl
