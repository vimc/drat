server_start()
