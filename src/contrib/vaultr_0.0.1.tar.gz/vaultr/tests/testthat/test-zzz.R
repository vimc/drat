server_teardown()
