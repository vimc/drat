# vaultr

[![Project Status: WIP - Initial development is in progress, but there has not yet been a stable, usable release suitable for the public.](http://www.repostatus.org/badges/latest/wip.svg)](http://www.repostatus.org/#wip)

API client for [vault](https://www.vaultproject.io/)

https://www.vaultproject.io/api/system/leader.html
