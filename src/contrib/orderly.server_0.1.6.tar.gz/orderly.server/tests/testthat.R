library(testthat)
library(orderly.server)

test_check("orderly.server")
