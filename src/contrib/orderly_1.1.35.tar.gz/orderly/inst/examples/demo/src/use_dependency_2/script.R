stopifnot(file.exists("graph.png"))

saveRDS(orderly::orderly_run_info(), "third.rds")
