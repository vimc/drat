INSERT INTO people(name, age, height)
VALUES ('Alice', 25, 175);
