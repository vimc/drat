## pkgapi

<!-- badges: start -->
[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![Build Status](https://travis-ci.com/reside-ic/pkgapi.svg?branch=master)](https://travis-ci.com/reside-ic/pkgapi)
[![codecov.io](https://codecov.io/github/reside-ic/pkgapi/coverage.svg?branch=master)](https://codecov.io/github/reside-ic/pkgapi?branch=master)
<!-- badges: end -->

## License

MIT © Imperial College of Science, Technology and Medicine
