## Reference data

This directory may hold reference data, but is not included in the package by default.  Files (`.zip`)  here can be safely deleted, and can be recopied by running `scripts/copy_reference` in the source distributuion root.
