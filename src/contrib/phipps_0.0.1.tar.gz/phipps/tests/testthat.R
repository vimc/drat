library(testthat)
library(PHIPPS)

test_check("PHIPPS")
