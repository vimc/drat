var count = 0;

/* eslint-disable */
function clicked() {
	var counter = document.getElementById("counter");
	count++;
	counter.innerText = count;
}
