context("counts-test")

testthat::test_that("No of rows in people increases by 2", {
  expect_equal(after$people_count, before$people_count + 2)
  expect_equal(after$jobs_count, before$jobs_count + 2)
})
