## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
default_reporter <- testthat::default_reporter()
options(testthat.default_reporter = "summary")

## -----------------------------------------------------------------------------
import_name <- withr::with_dir(tempdir(), 
  dettl::dettl_new("person_information")
)

## ----include = FALSE----------------------------------------------------------
path <- dettl::prepare_test_import(
  system.file("examples", "person_information", package = "dettl"),
  system.file("examples", "dettl_config.yml", package = "dettl"))
import_path <- file.path(path, "person_information")

## -----------------------------------------------------------------------------
import <- dettl::dettl(import_path, db_name = "test")
import$extract()
extracted_data <- import$get_extracted_data()

## -----------------------------------------------------------------------------
print(extracted_data)

## -----------------------------------------------------------------------------
import$transform()
transformed_data <- import$get_transformed_data()

## -----------------------------------------------------------------------------
print(transformed_data)

## ----include = FALSE----------------------------------------------------------
path <- dettl::prepare_test_import(
  system.file("examples", "person_information", package = "dettl"),
  system.file("examples", "dettl_config.yml", package = "dettl"))
import_path <- file.path(path, "person_information")

## -----------------------------------------------------------------------------
extracted_data <- dettl::dettl_run_extract(import_path, db_name = "test")

## -----------------------------------------------------------------------------
transformed_data <- dettl::dettl_run_transform(import_path, db_name = "test")

## -----------------------------------------------------------------------------
dettl::dettl_run_load(import_path, db_name = "test")

## ----include = FALSE----------------------------------------------------------
path <- dettl::prepare_test_import(
  system.file("examples", "person_information", package = "dettl"),
  system.file("examples", "dettl_config.yml", package = "dettl"))
import_path <- file.path(path, "person_information")

## -----------------------------------------------------------------------------
import <- dettl::dettl(import_path, db_name = "test")

## -----------------------------------------------------------------------------
import$extract()
import$transform()
import$load()

## ----include = FALSE----------------------------------------------------------
## Get a clean DB for running import a second time
path <- dettl::prepare_test_import(
  system.file("examples", "person_information", package = "dettl"),
  system.file("examples", "dettl_config.yml", package = "dettl"))
import_path <- file.path(path, "person_information")
import <- dettl::dettl(import_path, db_name = "test")

## -----------------------------------------------------------------------------
import$extract()
import$transform()

## -----------------------------------------------------------------------------
extracted_data <- import$get_extracted_data()
transformed_data <- import$get_transformed_data()

## -----------------------------------------------------------------------------
import$load()

## -----------------------------------------------------------------------------
con <- import$get_connection()
DBI::dbGetQuery(con, "SELECT * FROM people")

## ----include = FALSE----------------------------------------------------------
## Get a clean DB for running dry run import
path <- dettl::prepare_test_import(
  system.file("examples", "person_information", package = "dettl"),
  system.file("examples", "dettl_config.yml", package = "dettl"))
import_path <- file.path(path, "person_information")
import <- dettl::dettl(import_path, db_name = "test")

## -----------------------------------------------------------------------------
import$extract()
import$transform()
import$load(dry_run = TRUE)

## ----echo = FALSE, results = "hide"-------------------------------------------
## Reset default reporter.
options(testthat.default_reporter = default_reporter)

## ----echo = FALSE-------------------------------------------------------------
people <- data.frame(c(1,2),
                     c("Alice", "Bob"),
                     c(25, 45),
                     c(175, 187),
                     stringsAsFactors = FALSE)
colnames(people) <- c("id", "name", "age", "height")
jobs <- data.frame(c(1, 2),
                   c("researcher", "developer"),
                   stringsAsFactors = FALSE)
colnames(jobs) <- c("person", "job")
knitr::kable(people, caption = "people")
knitr::kable(jobs, caption = "jobs")

