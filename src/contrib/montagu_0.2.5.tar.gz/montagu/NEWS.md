## 0.2.5

* Support new orderly pluggable remotes (VIMC-2453)

## 0.2.4

* Return proper error objects

## 0.2.3

* Simplified demographics caching
