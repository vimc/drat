library(testthat)
library(orderly.sharepoint)

test_check("orderly.sharepoint")
