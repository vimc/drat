# orderlyweb 0.1.8

* Can return orderly run metadata (`orderly_run.rds`) from OrderlyWeb (VIMC-3793)

# orderlyweb 0.1.3

* The ability to run reports has been restored (VIMC-3138)

# orderlyweb 0.1.2

* `orderlyweb_remote` now implements `url_report`, as expected by `orderly` >= 0.8.2 (VIMC-2421)
