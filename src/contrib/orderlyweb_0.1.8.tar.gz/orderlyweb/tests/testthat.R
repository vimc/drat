library(testthat)
library(orderlyweb)

test_check("orderlyweb")
