extract <- function(con) {
  "Executed extract function"
}
