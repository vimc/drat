### jenner 0.0.6 (2017-11-22)
 * create synthetic fvps for situations where - fvps is blank but given coverage 

### jenner 0.0.5 (2017-11-21)
 * start work on touchstone import
 * export `database_connection`

### jenner 0.0.4 (2017-11-16)
 * correct impact rate and impact rate type in output files
 * eliminate warning message caused by updating multiple touchstones in one report
 * remove unused codes
 * export mu_scale

### jenner 0.0.3 (2017-11-09)
 * fix suffix in summary_output
 * fix migrate coverage.sql to allow 'bestminus' type of activity (SDF6/7)
