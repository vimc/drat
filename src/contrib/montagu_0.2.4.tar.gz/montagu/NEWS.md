## 0.2.4

* Return proper error objects

## 0.2.3

* Simplified demographics caching
