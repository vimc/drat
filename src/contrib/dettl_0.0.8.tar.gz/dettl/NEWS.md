## 0.0.8

VIMC-3108 - Allow test_transform to refer to extracted_data

## 0.0.7

VIMC-3007 - Users can configure if an import to a particular DB needs to be
confirmed. If so they are asked a yes/no question when running load step.

## 0.0.6

VIMC-3022 - Allow upload to not specify serial PKs when they are not referenced
by any other data within the upload

## 0.0.5

VIMC-3015 - Expose automatic load function for use in custom load functions

## 0.0.4

VIMC-3004 - Use gert package instead of system calls to git

## 0.0.3

VIMC-2859 - Read foreign key constraints automatically from the database
