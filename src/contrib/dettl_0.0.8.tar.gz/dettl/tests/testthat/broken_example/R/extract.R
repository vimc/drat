extract <- function(path, con) {
  raw_data <- list()
}
