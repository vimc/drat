extract <- function(path, con) {
  "Executed extract function"
}
