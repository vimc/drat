## ----setup, include = FALSE, echo = FALSE, results = "hide"--------------
library(beers)
knitr::opts_chunk$set(
  collapse = TRUE,
  fig.width = 7,
  fig.height = 5,
  comment = "#>"
)

## ----example-------------------------------------------------------------
beers_int_ordinary(c(1, 2, 4, 8, 16, 32))
beers_int_modified(c(1, 2, 4, 8, 16, 32))
beers_sub_ordinary(c(10, 20, 40, 80, 160))
beers_sub_modified(c(10, 20, 40, 80, 160))

## ----ukr_interp, echo = FALSE--------------------------------------------

ukr <- data.frame(pop = c(37297648, 40019449, 42662149, 45261935, 47086761, 48758987,
                          49968812, 50920778, 51464348, 50905677, 48840074, 46892163,
                          45792501, 44657704, 43579234, 42452647, 41200374, 39896340,
                          38658013, 37512851, 36415702, 35315013, 34190485, 33061130,
                          31992330, 31056617, 30287940, 29673481, 29160406, 28678792,
                          28185563),
	          year = seq(1950, 2100, 5))

ukr$pop = ukr$pop / 1000.0

ordinary <- data.frame(pop = beers_int_ordinary(ukr$pop),
                       year = seq(1950,2100,1))

modified <- data.frame(pop = beers_int_modified(ukr$pop),
                       year = seq(1950,2100,1))

app_lin <- approx(x = ukr$year, y = ukr$pop, xout = seq(1950,2100,1), method="linear")

r_spline <- spline(x = ukr$year, y = ukr$pop, n = 151, method = "fmm")

plot(x = ukr$year, y = ukr$pop, main = "Interpolated Population of Ukraine",
     xlab = "Year", ylab = "Population (k)")

  lines(x = ordinary$year, y = ordinary$pop, col = "red")
  lines(x = modified$year, y = modified$pop, col = "blue")
  lines(x = app_lin$x, y = app_lin$y, col = "darkgreen")
  lines(x = r_spline$x, y = r_spline$y, col = "brown")
  legend("topright",
      legend = c("Original", "Beers Ordinary", "Beers Modified", 
                 "R approx-linear", "R spline"),
      col = c("black", "red", "blue", "darkgreen", "brown"),
      lty = c(NA, 1, 1, 1, 1),
      pch = c(1, NA, NA, NA, NA)
    )

plot(x = ukr$year, y = ukr$pop, main = "Interpolated Population of Ukraine",
     xlim = c(1980,1995), ylim = c(49500,51500), xlab = "Year", ylab = "Population (k)")

  lines(x = ordinary$year, y = ordinary$pop, col = "red")
  lines(x = modified$year, y = modified$pop, col = "blue")
  lines(x = app_lin$x, y = app_lin$y, col = "darkgreen")
  lines(x = r_spline$x, y = r_spline$y, col = "brown")
  legend("bottomright",
      legend = c("Original", "Beers Ordinary", "Beers Modified", 
                 "R approx-linear", "R spline"),
      col = c("black", "red", "blue", "darkgreen", "brown"),
      lty = c(NA, 1, 1, 1, 1),
      pch = c(1, NA, NA, NA, NA)
    )



