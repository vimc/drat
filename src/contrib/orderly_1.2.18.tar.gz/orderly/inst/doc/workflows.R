## ----echo = FALSE, results = "hide"-------------------------------------------
lang_output <- function(x, lang) {
  writeLines(c(sprintf("```%s", lang), x, "```"))
}
r_output <- function(x) lang_output(x, "r")
yaml_output <- function(x) lang_output(x, "yaml")
path <- orderly:::prepare_orderly_example("demo")
## Even simpler
unlink(file.path(path, "archive"), recursive = TRUE)
unlink(file.path(path, "draft"), recursive = TRUE)
unlink(file.path(path, "data"), recursive = TRUE)
unlink(file.path(path, "data"), recursive = TRUE)
remove_files <- setdiff(list.files(file.path(path, "src"), full.names = TRUE), 
                        file.path(path, "src", c("minimal", "global")))
for (file in remove_files) {
  unlink(file, recursive = TRUE)
}
unlink(file.path(path, "before.R"))
unlink(file.path(path, "source.R"))
unlink(file.path(path, "demo.yml"))
unlink(file.path(path, "README.md"))
unlink(file.path(path, "src", "README.md"))

dir_tree <- function(path) {
  withr::with_dir(path, fs::dir_tree("."))
}

## ----comment = NA, echo = FALSE-----------------------------------------------
dir_tree(path)

## ----results = "asis", echo = FALSE-------------------------------------------
yaml_output(readLines(file.path(path, "workflows", "my_workflow.yml")))

## -----------------------------------------------------------------------------
out <- orderly::orderly_workflow("my_workflow", root = path)

## -----------------------------------------------------------------------------
out

