This report uses a resource, and also lists a README in the resources
