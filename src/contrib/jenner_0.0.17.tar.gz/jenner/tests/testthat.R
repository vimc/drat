library(testthat)
library(jenner)

test_check("jenner")
