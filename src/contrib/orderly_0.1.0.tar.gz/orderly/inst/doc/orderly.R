## ----echo = FALSE, results = "hide"--------------------------------------
lang_output <- function(x, lang) {
  writeLines(c(sprintf("```%s", lang), x, "```"))
}
r_output <- function(x) lang_output(x, "r")
yaml_output <- function(x) lang_output(x, "yaml")
plain_output <- function(x) lang_output(x, "plain")
orderly_file <- function(...) {
  system.file(..., package = "orderly", mustWork = TRUE)
}

path <- orderly:::prepare_orderly_example("example")
path_example <- file.path(path, "src", "example")
orderly:::orderly_default_config_set(orderly:::orderly_config(path))
orderly::orderly_log_start()

tree <- function(path, header = path) {
  paste1 <- function(a, b) {
    paste(rep_len(a, length(b)), b)
  }
  indent <- function(x, files) {
    paste0(if (files) "| " else "  ", x)
  }
  is_directory <- function(x) {
    unname(file.info(x)[, "isdir"])
  }
  sort_files <- function(x) {
    i <- grepl("^[A-Z]", x)
    c(x[i], x[!i])
  }
  prefix_file <- "|--="
  prefix_dir  <- "|-+="

  files <- sort_files(dir(path))
  files_full <- file.path(path, files)
  isdir <- is_directory(files_full)

  ret <- as.list(c(paste1(prefix_dir, files[isdir]),
                   paste1(prefix_file, files[!isdir])))
  files_full <- c(files_full[isdir], files_full[!isdir])
  isdir <- c(isdir[isdir], isdir[!isdir])

  n <- length(ret)
  if (n > 0) {
    ret[[n]] <- sub("|", "\\", ret[[n]], fixed = TRUE)
    tmp <- lapply(which(isdir), function(i)
      c(ret[[i]], indent(tree(files_full[[i]], NULL), !all(isdir))))
    ret[isdir] <- tmp
  }

  c(header, unlist(ret))
}

## ----results = "asis", echo = FALSE--------------------------------------
yaml_output(readLines(file.path(path_example, "orderly.yml")))

## ----results = "asis", echo = FALSE--------------------------------------
yaml_output(readLines(file.path(path_example, "script.R")))

## ----results = "asis", echo = FALSE--------------------------------------
plain_output(tree(path, "<root>"))

## ----results = "asis", echo = FALSE--------------------------------------
yaml_output(readLines(file.path(path, "orderly_config.yml")))

## ------------------------------------------------------------------------
orderly::orderly_list()

## ----collapse = TRUE-----------------------------------------------------
id <- orderly::orderly_run("example", list(cyl = 4))

## ----echo = FALSE, results = "hide"--------------------------------------
h <- sub("\\.rds$", "", dir(file.path(path, "data", "rds")))

## ------------------------------------------------------------------------
id

## ----results = "asis", echo = FALSE--------------------------------------
plain_output(tree(path, "<root>"))

## ------------------------------------------------------------------------
orderly::orderly_list_drafts()

## ----collapse = TRUE-----------------------------------------------------
orderly::orderly_commit(id)

## ----results = "asis", echo = FALSE--------------------------------------
plain_output(tree(path, "<root>"))

## ------------------------------------------------------------------------
dir.create(file.path(path, "src", "new"))

