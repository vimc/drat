library(testthat)
library(spud)

test_check("spud")
