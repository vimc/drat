.onLoad <- function(...) {
  montagu_add_location_defaults()
}
