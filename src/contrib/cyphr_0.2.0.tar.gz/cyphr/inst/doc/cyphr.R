## ----echo = FALSE, results = "hide"--------------------------------------
local({
  if (!file.exists("alice")) {
    dir.create("alice")
    cyphr::ssh_keygen("alice", FALSE)
  }
  if (!file.exists("bob")) {
    dir.create("bob")
    cyphr::ssh_keygen("bob", FALSE)
  }
  Sys.setenv(USER_KEY = "alice")
  Sys.setenv(USER_PUBKEY = "alice")
})

## ------------------------------------------------------------------------
k <- openssl::aes_keygen()

## ------------------------------------------------------------------------
k

## ------------------------------------------------------------------------
key <- cyphr::key_openssl(k)
key

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("my secret string", key)

## ------------------------------------------------------------------------
cyphr::decrypt_string(secret, key)

## ------------------------------------------------------------------------
k <- sodium::keygen()

## ------------------------------------------------------------------------
key <- cyphr::key_sodium(k)
key

## ------------------------------------------------------------------------
dir("alice")

## ------------------------------------------------------------------------
pair_a <- cyphr::keypair_openssl("bob", "alice")
pair_a

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("secret message", pair_a)

## ------------------------------------------------------------------------
secret

## ----error = TRUE--------------------------------------------------------
cyphr::decrypt_string(secret, pair_a)

## ------------------------------------------------------------------------
pair_b <- cyphr::keypair_openssl("alice", "bob")

## ------------------------------------------------------------------------
cyphr::decrypt_string(secret, pair_b)

## ------------------------------------------------------------------------
secret2 <- cyphr::encrypt_string("another message", pair_b)
secret2

## ------------------------------------------------------------------------
cyphr::decrypt_string(secret2, pair_a)

## ------------------------------------------------------------------------
pair_us <- cyphr::keypair_openssl("bob", NULL)

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("secret message", pair_us)
secret

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("secret message", pair_a)
writeBin(secret, "for_bob_only")

## ------------------------------------------------------------------------
secret <- readBin("for_bob_only", raw(), file.size("for_bob_only"))
cyphr::decrypt_string(secret, pair_b)

## ------------------------------------------------------------------------
secret_base64 <- openssl::base64_encode(secret)
secret_base64

## ------------------------------------------------------------------------
identical(openssl::base64_decode(secret_base64), secret)

## ------------------------------------------------------------------------
secret_hex <- sodium::bin2hex(secret)
secret_hex

## ------------------------------------------------------------------------
identical(sodium::hex2bin(secret_hex), secret)

## ------------------------------------------------------------------------
key_a <- sodium::keygen()
pub_a <- sodium::pubkey(key_a)

## ------------------------------------------------------------------------
key_b <- sodium::keygen()
pub_b <- sodium::pubkey(key_b)

## ------------------------------------------------------------------------
pair_a <- cyphr::keypair_sodium(pub_b, key_a)

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("secret message", pair_a)
secret

## ------------------------------------------------------------------------
pair_b <- cyphr::keypair_sodium(pub_a, key_b)
cyphr::decrypt_string(secret, pair_b)

## ------------------------------------------------------------------------
key <- cyphr::key_sodium(sodium::keygen())

## ------------------------------------------------------------------------
obj <- list(x = 1:10, y = "secret")

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_object(obj, key)
secret

## ------------------------------------------------------------------------
cyphr::decrypt_object(secret, key)

## ------------------------------------------------------------------------
path <- "secret.rds"
cyphr::encrypt_object(obj, key, path)

## ------------------------------------------------------------------------
file.exists(path)

## ----error = TRUE--------------------------------------------------------
readRDS(path)

## ------------------------------------------------------------------------
cyphr::decrypt_object(path, key)

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("secret", key)
secret

## ------------------------------------------------------------------------
cyphr::decrypt_string(secret, key)

## ------------------------------------------------------------------------
dat <- sodium::random(100)
dat # some random bytes

secret <- cyphr::encrypt_data(dat, key)
secret

## ------------------------------------------------------------------------
identical(cyphr::decrypt_data(secret, key), dat)

## ------------------------------------------------------------------------
write.csv(iris, "iris.csv", row.names = FALSE)

## ------------------------------------------------------------------------
cyphr::encrypt_file("iris.csv", key, "iris.csv.enc")
file.exists("iris.csv.enc")

## ------------------------------------------------------------------------
cyphr::decrypt_file("iris.csv.enc", key, "iris2.csv")

## ------------------------------------------------------------------------
tools::md5sum(c("iris.csv", "iris2.csv"))

## ------------------------------------------------------------------------
key <- cyphr::key_sodium(sodium::keygen())
x <- list(a = 1:10, b = "don't tell anyone else")

## ------------------------------------------------------------------------
cyphr::encrypt(saveRDS(x, "secret.rds"), key)

## ----error = TRUE--------------------------------------------------------
readRDS("secret.rds")

## ------------------------------------------------------------------------
cyphr::decrypt(readRDS("secret.rds"), key)

## ------------------------------------------------------------------------
cyphr::encrypt_(quote(saveRDS(x, "secret.rds")), key)
cyphr::decrypt_(quote(readRDS("secret.rds")), key)

## ------------------------------------------------------------------------
key <- cyphr::key_sodium(sodium::keygen())

## ------------------------------------------------------------------------
secret <- cyphr::encrypt_string("my secret", key)

## ------------------------------------------------------------------------
cyphr::decrypt_string(secret, key)

## ------------------------------------------------------------------------
cyphr::session_key_refresh()

## ----error = TRUE--------------------------------------------------------
cyphr::decrypt_string(secret, key)

## ----echo = FALSE, results = "hide"--------------------------------------
Sys.unsetenv("USER_KEY")
file.remove(c("secret.rds", "iris.csv", "iris2.csv"))

